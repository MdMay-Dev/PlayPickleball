CREATE TABLE `audit` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session` text NOT NULL,
	`name` text NOT NULL,
	`action` text NOT NULL,
	`at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `registrations` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session` text NOT NULL,
	`name` text NOT NULL,
	`normalized` text NOT NULL,
	`token` text NOT NULL,
	`paid` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `registration_name` ON `registrations` (`session`,`normalized`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`template` text NOT NULL,
	`week` text NOT NULL,
	`date` text NOT NULL,
	`title` text NOT NULL,
	`time` text NOT NULL,
	`capacity` integer NOT NULL,
	`payid` text NOT NULL,
	`fee` text NOT NULL,
	`venue` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `templates` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`day` integer NOT NULL,
	`time` text NOT NULL,
	`capacity` integer NOT NULL,
	`payid` text NOT NULL,
	`fee` text NOT NULL,
	`venue` text NOT NULL
);
--> statement-breakpoint
CREATE TRIGGER registration_join AFTER INSERT ON registrations BEGIN
 INSERT INTO audit(session,name,action,at) VALUES(NEW.session,NEW.name,CASE WHEN (SELECT count(*) FROM registrations WHERE session=NEW.session AND id<=NEW.id)<=(SELECT capacity FROM sessions WHERE id=NEW.session) THEN 'Joined playing list' ELSE 'Joined waitlist' END,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
 INSERT INTO audit(session,name,action,at) SELECT NEW.session,NEW.name,'Marked paid (self-reported)',strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NEW.paid=1;
END;
--> statement-breakpoint
CREATE TRIGGER registration_leave BEFORE DELETE ON registrations BEGIN
 INSERT INTO audit(session,name,action,at) VALUES(OLD.session,OLD.name,'Withdrew',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
 INSERT INTO audit(session,name,action,at) SELECT OLD.session,name,'Promoted from waitlist',strftime('%Y-%m-%dT%H:%M:%fZ','now') FROM registrations WHERE session=OLD.session AND (SELECT count(*) FROM registrations WHERE session=OLD.session AND id<=OLD.id)<=(SELECT capacity FROM sessions WHERE id=OLD.session) ORDER BY id LIMIT 1 OFFSET (SELECT capacity FROM sessions WHERE id=OLD.session);
END;
--> statement-breakpoint
CREATE TRIGGER registration_payment AFTER UPDATE OF paid ON registrations WHEN OLD.paid<>NEW.paid BEGIN
 INSERT INTO audit(session,name,action,at) VALUES(NEW.session,NEW.name,CASE WHEN NEW.paid=1 THEN 'Marked paid (self-reported)' ELSE 'Removed payment tick' END,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
END;
