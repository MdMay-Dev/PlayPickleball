# Geraldton Pickleball

Mobile-friendly weekly pickleball registration with persistent shared data.

## Features

- Multiple dated weekly sessions, custom days/times, venues, prices, PayID and capacity (12-player Sunday default).
- Public playing list and unlimited first-in-first-promoted waitlist.
- Register/Withdraw, private device cookies with optional Remember me, and self-reported payment ticks.
- PayID Copy button, native mobile sharing, PNG/SVG QR downloads.
- Password-protected organiser settings, Add/Remove players, payment visibility, audit history and archives.
- Perth weekly rollover. The included Cloudflare cron runs at Sunday 16:00 UTC (Monday midnight Perth); request-time creation is an idempotent fallback.

## Import into GitHub

Unzip the package. Create an empty repository in GitHub without a generated README or license. Open a terminal in this directory:

```sh
git init
git add .
git commit -m "Import Geraldton Pickleball"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/geraldton-pickleball.git
git push -u origin main
```

GitHub stores the code. A Worker and D1 database host the live application; GitHub Pages cannot run its backend.

## Run locally

Requires Node.js 24 and npm. On Windows use PowerShell or a terminal supporting npm.

```sh
npm ci
```

Copy `.dev.vars.example` to `.dev.vars` and set a long random `ORGANISER_KEY` privately.

```sh
npm run db:local
npm run dev
```

Use the URL printed by the dev server. New databases start with empty lists and configurable Sunday session details. Open `/organiser` with your password to set time, venue, fee and PayID.

## Deploy on your own Cloudflare account

1. Run `npx wrangler login` and `npx wrangler d1 create geraldton-pickleball`.
2. Replace `database_id` in `wrangler.deploy.jsonc` with the returned real database ID. Keep binding `DB`.
3. Run `npm run db:remote` to apply the schema/migrations to a new empty D1 database.
4. Build and deploy:

```sh
npm run deploy
```

5. Set the organiser secret before inviting users:

```sh
npx wrangler secret put ORGANISER_KEY --config wrangler.deploy.jsonc
```

6. Generate QR assets for the actual published URL and redeploy:

```sh
npm install --no-save --package-lock=false qrcode@1.5.4
npm run qr -- https://YOUR-ACTUAL-PUBLISHED-URL
npm run deploy
```

The included QR assets currently point to the existing Geraldton Pickleball site. Runtime Share and copied-list links use the new deployment's origin automatically.

Cloudflare cron requires an independently deployed Worker with the included `wrangler.deploy.jsonc`; other hosts must configure an equivalent schedule. Data remains in D1 across deployments.

## Use ChatGPT Sites instead

The source includes `.openai/hosting.json` with logical DB binding and no work-account project ID. Create a NEW Site in the intended account, insert its returned project ID and publish through Sites. Do not reuse the original work Site's project ID. Set its hosted `ORGANISER_KEY` privately. Configure a supported scheduled rollover there if it must run while no one accesses the app.

## Existing data

No player names, PayID values, private database snapshots or passwords are included. Import the separate private migration export if existing registrations/audit history must be preserved. Do not commit it to GitHub. That earlier export is a dated snapshot, not current live data. Apply schema and data through an import strategy that avoids duplicate trigger-generated audit entries.

Device cookies do not transfer to a new domain. Imported registrations may require organiser assistance for withdrawal. Never replace cookie ownership checks with name-only withdrawal.

## Checks

```sh
npm run check
npm test
npm run build
```

GitHub Actions runs these on pushes and pull requests. No automatic deployment or account credentials are configured.

## Implementation

React / TypeScript / vinext, Cloudflare Workers, D1 SQLite, Drizzle schema/migrations. `app/api/registration/route.ts` handles the API, `lib/booking.ts` handles sessions/rosters and `lib/player-cookie.ts` handles device cookies. Audit triggers preserve join/withdraw/payment events; organiser add/remove entries are recorded transactionally.

Payment flags are self-reported, not bank verified. Shared organiser-password access has no individual admin identities. Same-name registration collisions require initials. Keep the organiser secret private; rotate it through hosting settings.
