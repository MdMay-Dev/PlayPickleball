export type Profile={name:string,token:string,remember:boolean};
export function playerProfile(request:Request):Profile|null {
  try {
    const value=request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('pickleball-player='))?.slice('pickleball-player='.length);
    if(!value)return null;
    const p=JSON.parse(decodeURIComponent(value));
    return typeof p.name==='string'&&p.name.length<=60&&typeof p.token==='string'&&/^[a-f0-9-]{36}$/.test(p.token)?{name:p.name,token:p.token,remember:p.remember===true}:null;
  }catch{return null;}
}
export function profileCookie(profile:Profile,request:Request){
  return `pickleball-player=${encodeURIComponent(JSON.stringify(profile))}; Path=/; HttpOnly; SameSite=Lax${new URL(request.url).protocol==='https:'?'; Secure':''}${profile.remember?'; Max-Age=31536000':''}`;
}
