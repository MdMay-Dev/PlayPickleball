import {test} from 'node:test';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Miniflare} from 'miniflare';
import ts from 'typescript';

test('registration ownership, privacy, capacity, promotion, organiser actions and archives',async()=>{
 const mf=new Miniflare({modules:true,script:'export default {fetch(){return new Response("ok")}}',d1Databases:{DB:'test'},compatibilityDate:'2026-05-15'});
 const dir=await mkdtemp(join(tmpdir(),'pickleball-test-'));
 try{
  const db=await mf.getD1Database('DB');
  for(const sql of (await readFile('drizzle/0000_light_mimic.sql','utf8')).split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql).run();
  globalThis.__pickleballTestEnv={DB:db,ORGANISER_KEY:'test-only-key'};
  for(const [file,target] of [['lib/booking.ts','booking'],['lib/player-cookie.ts','player-cookie'],['app/api/registration/route.ts','route']]){
   const code=(await readFile(file,'utf8')).replace("import { env } from 'cloudflare:workers';",'const env=globalThis.__pickleballTestEnv;').replaceAll("'../../../lib/booking'","'./booking.mjs'").replaceAll("'../../../lib/player-cookie'","'./player-cookie.mjs'");
   await writeFile(join(dir,target+'.mjs'),ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
  }
  const {GET,POST}=await import(pathToFileURL(join(dir,'route.mjs')).href);
  const {weekAt}=await import(pathToFileURL(join(dir,'booking.mjs')).href);
  assert.equal(weekAt(new Date('2026-10-04T15:59:59Z')),'2026-09-28');
  assert.equal(weekAt(new Date('2026-10-04T16:00:00Z')),'2026-10-05');
  const get=(query='',cookie='',key='')=>GET(new Request('https://test.local/api/registration'+query,{headers:{cookie,Authorization:key?'Bearer '+key:''}}));
  const post=(body,cookie='',key='')=>POST(new Request('https://test.local/api/registration',{method:'POST',headers:{'Content-Type':'application/json',cookie,Authorization:key?'Bearer '+key:''},body:JSON.stringify(body)}));
  const first=await (await get()).json();const session=first.session.id;
  assert.equal((await get('?admin=1')).status,403);
  const a=await post({action:'in',session,name:'Alice',paid:true,remember:true});const cookie=a.headers.get('set-cookie');
  assert.equal(a.status,200);assert.match(cookie,/HttpOnly/);assert.match(cookie,/Secure/);assert.match(cookie,/Max-Age=31536000/);assert.equal((await a.json()).own.paid,1);
  const pub=await (await get()).json();assert.equal(pub.players[0].name,'Alice');assert.equal(pub.players[0].paid,undefined);assert.equal(pub.history,undefined);assert.equal(pub.own,null);
  assert.equal((await post({action:'out',session,name:'Alice'})).status,403);
  assert.equal((await post({action:'in',session,name:'Alice'})).status,409);
  await Promise.all(Array.from({length:12},(_,i)=>post({action:'in',session,name:'Player '+i})));
  const full=await (await get()).json();assert.equal(full.available,0);assert.equal(full.waitlist,1);const promoted=full.players[12].name;
  assert.equal((await post({action:'out',session,name:'Alice'},cookie)).status,200);
  const after=await (await get()).json();assert.equal(after.waitlist,0);assert.equal(after.players[11].name,promoted);
  assert.equal((await post({action:'adminAdd',session,name:'Guest'})).status,403);
  assert.equal((await post({action:'adminRemove',session,playerId:after.players[0].id})).status,403);
  const added=await (await post({action:'adminAdd',admin:true,session,name:'Guest'},'','test-only-key')).json();assert.equal(added.players[12].name,'Guest');assert.ok(added.history.some(x=>x.action==='Added by organiser'));
  const removed=await (await post({action:'adminRemove',admin:true,session,playerId:added.players[0].id},'','test-only-key')).json();assert.equal(removed.players[11].name,'Guest');assert.ok(removed.history.some(x=>x.action==='Removed by organiser'));
  assert.equal((await (await get('',cookie)).json()).profile.name,'Alice');
  await db.prepare("INSERT INTO sessions SELECT 'archive',template,'2026-01-05',date,title,time,capacity,payid,fee,venue FROM sessions WHERE id=?").bind(session).run();
  assert.ok(!(await (await get()).json()).sessions.some(x=>x.id==='archive'));
  assert.equal((await post({action:'adminAdd',session:'archive',name:'Nobody'},'','test-only-key')).status,409);
 }finally{await mf.dispose();await rm(dir,{recursive:true,force:true});delete globalThis.__pickleballTestEnv;}
});
