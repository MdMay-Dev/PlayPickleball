import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Geraldton Pickleball',description:'Join weekly pickleball sessions, see the player list and waitlist, and confirm payment.',robots:{index:false,follow:false},icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en-AU"><body>{children}</body></html>}
