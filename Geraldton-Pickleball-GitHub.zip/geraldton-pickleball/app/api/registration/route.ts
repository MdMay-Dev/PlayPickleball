import {playerProfile,profileCookie, type Profile} from '../../../lib/player-cookie';
import { database, snapshot, ensure, hash, admin, weekAt } from '../../../lib/booking';
export const dynamic='force-dynamic';
function json(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store'}});}
export async function GET(request:Request){try{const u=new URL(request.url),isAdmin=u.searchParams.get('admin')==='1';if(isAdmin&&!admin(request))return json({error:'Organiser access required.'},403);const p=playerProfile(request);return json({...await snapshot(u.searchParams.get('session')||undefined,isAdmin,p?.token),profile:p?{name:p.name,remember:p.remember}:null});}catch(e){console.error(e);return json({error:'Unable to load registrations. Try again.'},503);}}
export async function POST(request:Request){try{const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return json({error:'Invalid request origin.'},403);const b=await request.json() as Record<string,any>;await ensure();const db=database();
let profile=playerProfile(request);
async function result(session?:string,newProfile?:Profile){const p=newProfile||profile;const response=json({...await snapshot(session,b.admin===true&&admin(request),p?.token),profile:p?{name:p.name,remember:p.remember}:null});if(newProfile)response.headers.set('Set-Cookie',profileCookie(newProfile,request));return response;}
if(b.action==='remember'){const name=typeof b.name==='string'?b.name.trim().replace(/\s+/g,' '):'';if(!name||name.length>60)return json({error:'Enter your name first.'},400);return result(b.session,{name,token:profile?.token||crypto.randomUUID(),remember:b.remember===true});}

if(b.action==='addSession'||b.action==='settings'){if(!admin(request))return json({error:'Organiser access required.'},403);const capacity=Number(b.capacity),day=Number(b.day);if(!Number.isInteger(capacity)||capacity<1||capacity>500||!Number.isInteger(day)||day<0||day>6||typeof b.title!=='string'||!b.title.trim()||b.title.length>80||!/^$|^([01]\d|2[0-3]):[0-5]\d$/.test(b.time||'')||[b.payid,b.fee,b.venue].some(x=>typeof x!=='string'||x.length>160))return json({error:'Check the session details.'},400);const id=b.action==='settings'?'sunday':crypto.randomUUID();await db.prepare('INSERT INTO templates (id,title,day,time,capacity,payid,fee,venue) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,day=excluded.day,time=excluded.time,capacity=excluded.capacity,payid=excluded.payid,fee=excluded.fee,venue=excluded.venue').bind(id,b.title.trim(),day,b.time||'',capacity,b.payid.trim(),b.fee.trim(),b.venue.trim()).run();if(b.action==='settings'){const sid='sunday:'+weekAt();await db.batch([db.prepare('UPDATE sessions SET title=?,date=?,time=?,capacity=?,payid=?,fee=?,venue=? WHERE id=?').bind(b.title.trim(),(await import('../../../lib/booking')).dateFor(weekAt(),day),b.time||'',capacity,b.payid.trim(),b.fee.trim(),b.venue.trim(),sid),db.prepare('INSERT INTO audit(session,name,action,at) VALUES (?,?,?,?)').bind(sid,'Organiser','Updated session details',new Date().toISOString())]);}return result(id+':'+weekAt());}
const organiserAction=b.action==='adminAdd'||b.action==='adminRemove';
if(organiserAction&&!admin(request))return json({error:'Organiser access required.'},403);
const s=await db.prepare('SELECT * FROM sessions WHERE id=?').bind(String(b.session||'')).first<any>();if(!s||s.week!==weekAt())return json({error:'This session is archived and cannot be changed.'},409);
if(b.action==='adminRemove'){
 const id=Number(b.playerId);if(!Number.isSafeInteger(id)||id<1)return json({error:'Choose a registered player.'},400);
 const player=await db.prepare('SELECT id FROM registrations WHERE id=? AND session=?').bind(id,s.id).first();
 if(!player)return json({error:'This player is no longer registered. Refresh the list.'},409);
 await db.batch([
  db.prepare("INSERT INTO audit(session,name,action,at) SELECT session,name,'Removed by organiser',? FROM registrations WHERE id=? AND session=?").bind(new Date().toISOString(),id,s.id),
  db.prepare('DELETE FROM registrations WHERE id=? AND session=?').bind(id,s.id)
 ]);
 return result(s.id);
}
const name=typeof b.name==='string'?b.name.trim().replace(/\s+/g,' '):'';if(!name||name.length>60)return json({error:'Enter your name (up to 60 characters).'},400);const normalized=name.toLocaleLowerCase();const existing=await db.prepare('SELECT * FROM registrations WHERE session=? AND normalized=?').bind(s.id,normalized).first<any>();const credential=profile?.token||(typeof b.token==='string'?b.token:'');
if(!profile&&existing&&credential&&await hash(credential)===existing.token)profile={name:existing.name,token:credential,remember:b.remember===true};
if(b.action==='adminAdd'){
 if(existing)return json({error:'That name is already registered. Add an initial if they share a name.'},409);
 const created=new Date().toISOString();
 await db.batch([
  db.prepare('INSERT INTO registrations(session,name,normalized,token,paid,created) VALUES (?,?,?,?,?,?)').bind(s.id,name,normalized,await hash(crypto.randomUUID()),b.paid===true?1:0,created),
  db.prepare('INSERT INTO audit(session,name,action,at) VALUES (?,?,?,?)').bind(s.id,name,'Added by organiser',created)
 ]);
 return result(s.id);
}
if(b.action==='in'){if(existing)return json({error:'That name is already registered. Add an initial if you share a name.'},409);const token=profile?.token||crypto.randomUUID();await db.prepare('INSERT INTO registrations(session,name,normalized,token,paid,created) VALUES (?,?,?,?,?,?)').bind(s.id,name,normalized,await hash(token),b.paid===true?1:0,new Date().toISOString()).run();return result(s.id,{name,token,remember:b.remember===true});}
if(!existing||!credential||await hash(credential)!==existing.token)return json({error:'Use the device you registered on. The organiser can help if you have changed devices.'},403);
if(b.action==='restore')return result(s.id,profile||undefined);
if(b.action==='out')await db.prepare('DELETE FROM registrations WHERE id=?').bind(existing.id).run();else if(b.action==='paid')await db.prepare('UPDATE registrations SET paid=? WHERE id=?').bind(b.paid===true?1:0,existing.id).run();else return json({error:'Unknown action.'},400);return result(s.id,profile||undefined);
}catch(e){console.error(e);return json({error:'Unable to save. Refresh the list before trying again.'},503);}}
