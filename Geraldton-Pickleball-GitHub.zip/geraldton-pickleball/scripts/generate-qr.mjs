import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
const require=createRequire(import.meta.url);
let QR;try{QR=require('qrcode');}catch{throw new Error('Install the optional QR generator: npm install --no-save --package-lock=false qrcode@1.5.4');}
const input=process.argv[2];if(!input)throw new Error('Usage: npm run qr -- https://your-site.example');
const url=new URL(input);if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('Provide a public HTTP(S) site URL.');
const options={width:2400,margin:4,errorCorrectionLevel:'M'};
await QR.toFile('public/pickleball-qr.png',url.origin,options);
await writeFile('public/pickleball-qr.svg',await QR.toString(url.origin,{...options,type:'svg'}));
console.log('Generated QR assets for '+url.origin);
